Simple database application of the computer service as my project on university.

the project has functionalities such as:
- Login and registration
- Adding a new order by the user
- Modification and deletion of orders by the Administrator
- Displaying the orders of a given user with paging
- Filtering orders based on criteria
