<?php

namespace app\forms;

class PagesForm {

    public $p;


}
