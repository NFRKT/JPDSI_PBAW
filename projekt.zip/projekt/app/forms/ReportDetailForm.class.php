<?php

namespace app\forms;

class ReportDetailForm
{
    public $id;
    public $id_report;
    public $name;
    public $model;
    public $description;
    public $comment;
    public $cost;


}