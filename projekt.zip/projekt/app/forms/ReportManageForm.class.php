<?php

namespace app\forms;

class ReportManageForm
{
    public $id;
    public $id_report;
    public $name;
    public $surname;
    public $phone;
    public $model;
    public $description;
    public $comment;
    public $cost;
    public $id_repair;
    public $id_device;


}