<?php

namespace app\forms;

class LoginForm
{
    public $login;
    public $pass;
    public $surname;
    public $password;
    public $name;
}