<?php

namespace app\forms;

class ReportSearchForm
{
    public $id_report;
    public $id_status;
    public $number;
} 