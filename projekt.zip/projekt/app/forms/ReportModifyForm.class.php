<?php

namespace app\forms;

class ReportModifyForm
{
    public $id;
    public $id_report;
    public $name;
    public $model;
    public $description;
    public $comment;
    public $cost;
    public $id_status;


}