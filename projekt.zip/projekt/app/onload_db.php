<?php

/*
 * The script automatically executed when getDB() is called for the first time.
 * Use it for additional setup.
 */
#\core\App::getBD()->do_whatever_you_need();